@echo off
title ULTRON AI
cd /d "%~dp0"
echo.
echo  =====================================
echo       ULTRON AI - AppexioDevs
echo  =====================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found.
  echo Install Node.js 18 or newer from https://nodejs.org/
  echo Then reopen this file.
  pause
  exit /b 1
)
if not exist ".env" (
  copy ".env.example" ".env" >nul
  echo Created .env from .env.example
  echo Created local .env configuration.
  echo If you need to change provider settings, edit .env.
  echo.
)
node server.js
pause
