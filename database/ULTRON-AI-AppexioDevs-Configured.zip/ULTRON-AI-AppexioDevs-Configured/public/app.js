(() => {
  const $ = id => document.getElementById(id);
  const form = $("chatForm"), input = $("messageInput"), messagesEl = $("messages");
  const welcome = $("welcome"), historyEl = $("historyList"), sendBtn = $("sendBtn");
  const STORAGE_KEY = "ultron_conversations_v1";
  let conversations = loadConversations(), currentId = null, busy = false, toastTimer;

  function loadConversations() {
    try {
      const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
      return Array.isArray(data) ? data : [];
    } catch { return []; }
  }
  function saveConversations() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(conversations.slice(0, 40))); }
    catch { showToast("Browser storage is full. Export a conversation and clear old chats."); }
    renderHistory();
  }
  function getCurrent() { return conversations.find(c => c.id === currentId) || null; }
  function newConversation() {
    currentId = null;
    messagesEl.innerHTML = "";
    welcome.hidden = false;
    renderHistory();
    input.focus();
    if (window.innerWidth <= 760) $("sidebar").classList.remove("open");
  }
  function ensureConversation(firstText) {
    let c = getCurrent();
    if (!c) {
      c = { id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()), title: firstText.trim().slice(0, 42) || "New conversation", createdAt: Date.now(), messages: [] };
      conversations.unshift(c);
      currentId = c.id;
    }
    return c;
  }
  function renderHistory() {
    historyEl.innerHTML = "";
    if (!conversations.length) {
      const empty = document.createElement("div");
      empty.style.cssText = "padding:10px 9px;color:var(--faint);font-size:10px;line-height:1.6";
      empty.textContent = "Your conversations will appear here.";
      historyEl.appendChild(empty); return;
    }
    conversations.slice(0, 30).forEach(c => {
      const b = document.createElement("button");
      b.className = "history-item" + (c.id === currentId ? " active" : "");
      b.title = c.title;
      const icon = document.createElement("span"); icon.textContent = "◷";
      const label = document.createElement("span"); label.textContent = c.title; label.style.cssText = "overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:inherit";
      b.append(icon, label);
      b.addEventListener("click", () => openConversation(c.id));
      historyEl.appendChild(b);
    });
  }
  function openConversation(id) {
    currentId = id;
    const c = getCurrent();
    if (!c) return newConversation();
    messagesEl.innerHTML = "";
    welcome.hidden = true;
    c.messages.forEach(m => renderMessage(m.role, m.content, false));
    renderHistory();
    scrollBottom();
    if (window.innerWidth <= 760) $("sidebar").classList.remove("open");
  }
  function escapeHTML(s) {
    return String(s).replace(/[&<>"']/g, ch => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[ch]));
  }
  // Small, dependency-free Markdown renderer; raw HTML is escaped before formatting.
  function markdown(source) {
    let text = escapeHTML(source).replace(/\r\n/g, "\n");
    const blocks = [];
    text = text.replace(/```([\w.+#-]*)\n?([\s\S]*?)```/g, (_, lang, code) => {
      const token = `@@BLOCK${blocks.length}@@`;
      blocks.push(`<div class="code-wrap"><div class="code-head"><span>${escapeHTML(lang || "CODE").toUpperCase()}</span><button class="copy-code" type="button">Copy code</button></div><pre><code>${code.replace(/\n$/, "")}</code></pre></div>`);
      return token;
    });
    text = text.replace(/`([^`\n]+)`/g, "<code>$1</code>");
    text = text.replace(/^### (.+)$/gm, "<h3>$1</h3>").replace(/^## (.+)$/gm, "<h2>$1</h2>").replace(/^# (.+)$/gm, "<h1>$1</h1>");
    text = text.replace(/^&gt; ?(.+)$/gm, "<blockquote>$1</blockquote>");
    text = text.replace(/(\*\*|__)(.+?)\1/g, "<strong>$2</strong>").replace(/(\*|_)([^*\n]+)\1/g, "<em>$2</em>");
    text = text.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    text = text.replace(/^(?:-|\*) (.+)$/gm, "<li>$1</li>");
    text = text.replace(/(<li>[\s\S]*?<\/li>\n?)+/g, m => `<ul>${m}</ul>`);
    text = text.split(/\n{2,}/).map(part => {
      const p = part.trim();
      if (!p || /^@@BLOCK\d+@@$/.test(p) || /^<(h[1-3]|ul|ol|blockquote|div)\b/.test(p)) return p;
      return p.replace(/\n/g, "<br>");
    }).join("\n");
    text = text.replace(/@@BLOCK(\d+)@@/g, (_, n) => blocks[Number(n)]);
    return text;
  }
  function renderMessage(role, content, addActions = true) {
    const article = document.createElement("article");
    article.className = "message " + (role === "user" ? "user" : "assistant");
    const avatar = document.createElement("div"); avatar.className = "avatar";
    if (role === "assistant") {
      const img = document.createElement("img"); img.src = "/ultron.svg"; img.alt = "ULTRON"; avatar.appendChild(img);
    } else avatar.textContent = "YOU";
    const body = document.createElement("div"); body.className = "message-body";
    const meta = document.createElement("div"); meta.className = "message-meta"; meta.textContent = role === "user" ? "You" : "ULTRON";
    const text = document.createElement("div"); text.className = "message-text"; text.innerHTML = markdown(content);
    body.append(meta, text);
    if (role === "assistant" && addActions) {
      const actions = document.createElement("div"); actions.className = "message-actions";
      const copy = document.createElement("button"); copy.textContent = "▢  Copy response";
      copy.addEventListener("click", () => copyText(content));
      actions.appendChild(copy); body.appendChild(actions);
    }
    article.append(avatar, body); messagesEl.appendChild(article);
    article.querySelectorAll(".copy-code").forEach(btn => btn.addEventListener("click", () => {
      const code = btn.closest(".code-wrap").querySelector("code").textContent;
      copyText(code, "Code copied"); 
    }));
    return article;
  }
  function showTyping() {
    const article = document.createElement("article");
    article.className = "message assistant"; article.id = "typingMessage";
    article.innerHTML = '<div class="avatar"><img src="/ultron.svg" alt="ULTRON" style="width:24px;height:24px"></div><div class="message-body"><div class="message-meta">ULTRON is thinking</div><div class="typing-dots"><i></i><i></i><i></i></div></div>';
    messagesEl.appendChild(article); scrollBottom();
  }
  function scrollBottom() { const c = $("conversation"); requestAnimationFrame(() => { c.scrollTop = c.scrollHeight; }); }
  function showToast(message) {
    const t = $("toast"); t.textContent = message; t.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove("show"), 2600);
  }
  async function copyText(text, msg = "Copied to clipboard") {
    try { await navigator.clipboard.writeText(text); showToast(msg); }
    catch {
      const ta = document.createElement("textarea"); ta.value = text; document.body.appendChild(ta); ta.select();
      try { document.execCommand("copy"); showToast(msg); } catch { showToast("Could not copy automatically."); }
      ta.remove();
    }
  }
  async function refreshStatus() {
    try {
      const r = await fetch("/api/status"); const d = await r.json();
      $("providerName").textContent = d.configured ? `${d.provider} connected` : "Setup required";
      $("providerStatus").textContent = d.configured ? d.model : "Add API key in .env";
      $("statusDot").classList.toggle("ready", d.configured);
      $("modelLabel").textContent = d.model || "AI Assistant";
    } catch {
      $("providerName").textContent = "Server unavailable";
      $("providerStatus").textContent = "Restart start.bat";
    }
  }
  async function sendMessage(raw) {
    const content = raw.trim();
    if (!content || busy) return;
    const c = ensureConversation(content);
    c.messages.push({ role: "user", content });
    welcome.hidden = true;
    renderMessage("user", content, false);
    input.value = ""; resizeInput(); busy = true; sendBtn.disabled = true;
    saveConversations(); showTyping();
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: c.messages.map(m => ({ role: m.role, content: m.content })) })
      });
      const data = await response.json().catch(() => ({}));
      $("typingMessage")?.remove();
      if (!response.ok) throw new Error((data.error || "AI request failed") + (data.hint ? "\n" + data.hint : ""));
      c.messages.push({ role: "assistant", content: data.answer });
      renderMessage("assistant", data.answer);
      saveConversations();
    } catch (err) {
      $("typingMessage")?.remove();
      const msg = err.message || "Something went wrong.";
      renderMessage("assistant", "I couldn't complete that request.\n\n" + msg + "\n\nCheck your API key and provider settings in `.env`, then restart ULTRON.");
    } finally {
      busy = false; sendBtn.disabled = false; input.focus(); scrollBottom(); refreshStatus();
    }
  }
  function resizeInput() { input.style.height = "auto"; input.style.height = Math.min(input.scrollHeight, 180) + "px"; }
  function exportConversation() {
    const c = getCurrent();
    if (!c || !c.messages.length) return showToast("There is no conversation to export yet.");
    const content = `ULTRON AI — ${c.title}\nDeveloped by AppexioDevs (https://appexiodev.github.io)\n\n` + c.messages.map(m => `${m.role === "user" ? "YOU" : "ULTRON"}:\n${m.content}`).join("\n\n-----------------------------\n\n");
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([content], {type:"text/plain;charset=utf-8"}));
    a.download = (c.title || "ultron-chat").replace(/[^\w-]+/g, "-").slice(0,45) + ".txt"; a.click(); URL.revokeObjectURL(a.href);
  }
  function clearHistory() {
    if (!conversations.length) return showToast("Your history is already empty.");
    if (!confirm("Clear all saved ULTRON conversations from this browser?")) return;
    conversations = []; currentId = null; saveConversations(); messagesEl.innerHTML = ""; welcome.hidden = false; showToast("Conversation history cleared.");
  }

  form.addEventListener("submit", e => { e.preventDefault(); sendMessage(input.value); });
  input.addEventListener("input", resizeInput);
  input.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); form.requestSubmit(); }
  });
  $("newChat").addEventListener("click", newConversation);
  $("exportBtn").addEventListener("click", exportConversation);
  $("clearBtn").addEventListener("click", clearHistory);
  $("openSidebar").addEventListener("click", () => $("sidebar").classList.add("open"));
  $("closeSidebar").addEventListener("click", () => $("sidebar").classList.remove("open"));
  $("themeBtn").addEventListener("click", () => {
    document.body.classList.toggle("light");
    localStorage.setItem("ultron_theme", document.body.classList.contains("light") ? "light" : "dark");
  });
  document.querySelectorAll(".suggestion").forEach(b => b.addEventListener("click", () => { input.value = b.dataset.prompt; resizeInput(); sendMessage(input.value); }));
  document.addEventListener("keydown", e => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); newConversation(); }
    if (e.key === "Escape") $("sidebar").classList.remove("open");
  });
  try { if (localStorage.getItem("ultron_theme") === "light") document.body.classList.add("light"); } catch {}
  renderHistory();
  refreshStatus();
  if (conversations.length) {
    // Start on a clean welcome screen; past chats remain in the sidebar.
  }
})();
