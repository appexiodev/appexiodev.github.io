
const http = require("http");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, "public");

// Minimal .env loader, no third-party dependencies required.
function loadEnv() {
  const p = path.join(ROOT, ".env");
  if (!fs.existsSync(p)) return;

  for (const raw of fs.readFileSync(p, "utf8").split(/\r?\n/)) {
    const line = raw.trim();

    if (!line || line.startsWith("#")) continue;

    const i = line.indexOf("=");
    if (i < 1) continue;

    const key = line.slice(0, i).trim();
    let value = line.slice(i + 1).trim();

    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }

    if (!process.env[key]) process.env[key] = value;
  }
}

loadEnv();

const PORT = Number(process.env.PORT || 3000);
const PROVIDER = (process.env.AI_PROVIDER || "openrouter").toLowerCase();
const API_KEY = process.env.AI_API_KEY || "";
const MODEL =
  process.env.AI_MODEL ||
  (PROVIDER === "gemini" ? "gemini-2.5-flash" : "openrouter/free");

const OPENROUTER_MAX_TOKENS = 1000;
const GEMINI_MAX_TOKENS = 3000;

function send(
  res,
  status,
  body,
  type = "application/json; charset=utf-8"
) {
  res.writeHead(status, {
    "Content-Type": type,
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
    "Cache-Control": "no-store"
  });

  res.end(
    type.startsWith("application/json")
      ? JSON.stringify(body)
      : body
  );
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";

    req.on("data", chunk => {
      data += chunk;

      if (data.length > 1_500_000) {
        reject(new Error("Request is too large."));
        req.destroy();
      }
    });

    req.on("end", () => {
      try {
        resolve(JSON.parse(data || "{}"));
      } catch {
        reject(new Error("Invalid JSON request."));
      }
    });

    req.on("error", reject);
  });
}

function normalizeMessages(messages) {
  if (!Array.isArray(messages)) return [];

  return messages
    .filter(
      m =>
        m &&
        ["user", "assistant"].includes(m.role) &&
        typeof m.content === "string"
    )
    .slice(-40)
    .map(m => ({
      role: m.role,
      content: m.content.slice(0, 30000)
    }));
}

async function callOpenRouter(messages) {
  const response = await fetch(
    "https://openrouter.ai/api/v1/chat/completions",
    {
      method: "POST",

      headers: {
        Authorization: `Bearer ${API_KEY}`,
        "Content-Type": "application/json",
        "HTTP-Referer":
          process.env.HTTP_REFERER ||
          "http://localhost:" + PORT,
        "X-Title":
          process.env.APP_TITLE || "ULTRON AI by AppexioDevs"
      },

      body: JSON.stringify({
        model: MODEL,

        messages: [
          {
            role: "system",
            content:
              "You are ULTRON, a helpful, capable, friendly AI assistant developed by AppexioDevs. Be accurate, clear, and honest about uncertainty. Use readable formatting. Never claim you performed actions you did not perform."
          },
          ...messages
        ],

        temperature: 0.7,

        // Limit the maximum generated response to reduce output-token usage.
        max_tokens: OPENROUTER_MAX_TOKENS
      })
    }
  );

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const message =
      data?.error?.message ||
      data?.message ||
      `Provider returned HTTP ${response.status}`;

    throw Object.assign(new Error(message), {
      status: response.status
    });
  }

  const answer = data?.choices?.[0]?.message?.content;

  if (!answer) {
    throw new Error(
      "The AI provider returned an empty response."
    );
  }

  return {
    answer:
      typeof answer === "string"
        ? answer
        : JSON.stringify(answer),
    model: data.model || MODEL
  };
}

async function callGemini(messages) {
  const contents = messages.map(m => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.content }]
  }));

  contents.unshift({
    role: "user",
    parts: [
      {
        text:
          "You are ULTRON, a helpful, capable, friendly AI assistant developed by AppexioDevs. Be accurate, clear, and honest about uncertainty. Use readable formatting. Never claim you performed actions you did not perform."
      }
    ]
  });

  contents.splice(1, 0, {
    role: "model",
    parts: [
      {
        text: "Understood. I am ULTRON, ready to help."
      }
    ]
  });

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(
      MODEL
    )}:generateContent?key=${encodeURIComponent(API_KEY)}`,
    {
      method: "POST",

      headers: {
        "Content-Type": "application/json"
      },

      body: JSON.stringify({
        contents,

        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: GEMINI_MAX_TOKENS
        }
      })
    }
  );

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const message =
      data?.error?.message ||
      `Gemini returned HTTP ${response.status}`;

    throw Object.assign(new Error(message), {
      status: response.status
    });
  }

  const answer = data?.candidates?.[0]?.content?.parts
    ?.map(p => p.text || "")
    .join("")
    .trim();

  if (!answer) {
    throw new Error(
      data?.promptFeedback?.blockReason
        ? `The provider blocked this request (${data.promptFeedback.blockReason}).`
        : "The AI provider returned an empty response."
    );
  }

  return {
    answer,
    model: MODEL
  };
}

const server = http.createServer(async (req, res) => {
  const url = new URL(
    req.url,
    `http://${req.headers.host || "localhost"}`
  );

  if (
    req.method === "GET" &&
    url.pathname === "/api/status"
  ) {
    const configured = Boolean(
      API_KEY && !API_KEY.startsWith("put_your_")
    );

    return send(res, 200, {
      app: "ULTRON AI",
      provider: PROVIDER,
      model: MODEL,
      configured,
      message: configured
        ? "Ready"
        : "Add an API key to .env, then restart ULTRON."
    });
  }

  if (
    req.method === "POST" &&
    url.pathname === "/api/chat"
  ) {
    try {
      if (
        !API_KEY ||
        API_KEY.startsWith("put_your_")
      ) {
        return send(res, 400, {
          error:
            "ULTRON needs an API key. Open the .env file, add your provider key, and restart the app."
        });
      }

      const body = await readBody(req);
      const messages = normalizeMessages(body.messages);

      if (
        !messages.length ||
        messages[messages.length - 1].role !== "user"
      ) {
        return send(res, 400, {
          error: "Please enter a message first."
        });
      }

      const result =
        PROVIDER === "gemini"
          ? await callGemini(messages)
          : PROVIDER === "openrouter"
            ? await callOpenRouter(messages)
            : null;

      if (!result) {
        return send(res, 400, {
          error:
            "Unsupported AI_PROVIDER. Use openrouter or gemini in .env."
        });
      }

      return send(res, 200, {
        ...result,
        provider: PROVIDER
      });
    } catch (error) {
      const status =
        error.status &&
        error.status >= 400 &&
        error.status < 600
          ? error.status
          : 500;

      console.error("[ULTRON]", error.message);

      let hint = "";

      if (status === 429) {
        hint =
          "Provider rate limit or quota reached. Check your OpenRouter credits, model pricing, and key limits.";
      } else if (status === 401 || status === 403) {
        hint =
          "Check your API key, provider configuration, and model access in .env.";
      } else if (status === 402) {
        hint =
          "OpenRouter could not cover this request with the available credits or spending allowance. Check your balance, model pricing, and key limits.";
      }

      return send(res, status, {
        error:
          error.message ||
          "Something went wrong while contacting the AI provider.",
        hint
      });
    }
  }

  if (
    req.method !== "GET" &&
    req.method !== "HEAD"
  ) {
    return send(res, 405, {
      error: "Method not allowed."
    });
  }

  let pathname;

  try {
    pathname = decodeURIComponent(url.pathname);
  } catch {
    return send(res, 400, {
      error: "Invalid URL path."
    });
  }

  if (pathname === "/") {
    pathname = "/index.html";
  }

  const filePath = path.resolve(
    PUBLIC,
    "." + pathname
  );

  if (
    !filePath.startsWith(PUBLIC + path.sep) &&
    filePath !== path.join(PUBLIC, "index.html")
  ) {
    return send(res, 403, {
      error: "Forbidden"
    });
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      return send(
        res,
        404,
        "Not found",
        "text/plain; charset=utf-8"
      );
    }

    const ext = path.extname(filePath).toLowerCase();

    const types = {
      ".html": "text/html; charset=utf-8",
      ".css": "text/css; charset=utf-8",
      ".js": "text/javascript; charset=utf-8",
      ".svg": "image/svg+xml",
      ".png": "image/png",
      ".ico": "image/x-icon"
    };

    send(
      res,
      200,
      req.method === "HEAD" ? "" : data,
      types[ext] || "application/octet-stream"
    );
  });
});

server.listen(PORT, "127.0.0.1", () => {
  console.log("\n  ULTRON AI by AppexioDevs");
  console.log(`  Open: http://localhost:${PORT}`);
  console.log(`  Provider: ${PROVIDER} | Model: ${MODEL}`);

  if (
    !API_KEY ||
    API_KEY.startsWith("put_your_")
  ) {
    console.log(
      "  Setup needed: add your API key in .env and restart.\n"
    );
  } else {
    console.log(
      "  API key loaded from .env. Keep this app local and do not share .env.\n"
    );
  }
});

