# ULTRON AI — by AppexioDevs

A polished, responsive AI chat app with conversation history, Markdown-like formatting, code blocks with copy buttons, dark/light theme, export, and configurable AI provider.

## Quick start (Windows)

1. Install **Node.js 18 or newer** from https://nodejs.org/ if it is not already installed.
2. Double-click `start.bat`.
3. This bundle is preconfigured for OpenRouter with `openai/gpt-4o`; the key is loaded by the local Node.js backend and is not placed in browser JavaScript.
4. Open http://localhost:3000. If the provider rejects the key, model, or account quota, update `.env` with a valid key/model and restart.

To change providers: OpenRouter uses `AI_PROVIDER=openrouter`, `AI_API_KEY=your_key`, and `AI_MODEL=provider/model-name`. Gemini uses `AI_PROVIDER=gemini`, `AI_API_KEY=your_key`, and `AI_MODEL=gemini-2.5-flash`.

## Getting an API key

- OpenRouter keys: https://openrouter.ai/keys
- Google AI Studio / Gemini API: https://aistudio.google.com/apikey

Free-model availability, quotas and provider terms can change. OpenRouter's `openrouter/free` selects from available free models, so responses and capability may vary. API providers can require an account and may impose rate limits.

## Features

- ULTRON branded, responsive chat UI
- Server-side API calls: the API key stays in `.env` and is not sent to the browser
- Supports OpenRouter chat-completions and Gemini generateContent APIs
- Multi-turn context for the current conversation
- Local conversation history and new-chat controls
- Copy responses and code snippets
- Export current conversation as a text file
- Dark/light theme and mobile layout
- Clickable AppexioDevs credit linking to https://appexiodev.github.io

## Security notes

- This ZIP includes the API key supplied for setup inside `.env`. Treat the ZIP and `.env` as secret: do not upload them to GitHub or send the ZIP to others. Because the key was pasted into a chat, the safest practice is to revoke/rotate it in OpenRouter and replace it in `.env` before continued use. Never expose the key in browser JavaScript.
- This is a local personal-use starter app, not a secured public multi-user service. Before hosting it publicly, add authentication, request limits, abuse protection, and deployment-specific secret management.
- ULTRON is an independent project and is not an official OpenAI/ChatGPT product. It uses whichever provider you configure.

## Troubleshooting

- **“API key not configured”**: open `.env`, add your real key, save, and restart `start.bat`.
- **401/403**: check the key and provider settings.
- **429 / quota**: you have reached a provider limit; wait or check your provider dashboard.
- **Model not found**: change `AI_MODEL` in `.env` to a model currently supported by your provider.
- If the port is busy, change `PORT=3000` to another port such as `PORT=3001`, then restart.
